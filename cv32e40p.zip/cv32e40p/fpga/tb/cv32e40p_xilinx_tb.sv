`timescale 1ns/1ns// testbench for the testharness module
module cv32e40p_xilinx_tb;

  // Signals for the testharness module
  logic clk_i;
  logic rst_ni;
  logic tck_i;
  logic tms_i;
  logic td_i;
  logic td_o;
  logic trst_ni;
  logic clk_led;
  logic tck_led;
  logic simulation_done;

  // Instantiate the testharness module
  cv32e40p_xilinx i_cv32e40p_xilinx (
    .clk_i(clk_i),
    .rst_ni(rst_ni),
    .tck_i,
    .tms_i,
    .td_i,
    .td_o,
    .clk_led,
    .tck_led
  );


  // Clock generation (50% duty cycle)
  always #5 clk_i = ~clk_i;

  // Testbench initial block
  initial begin
    // Initialize signals
   

    clk_i = 0;
    rst_ni = 0;
    tck_i = 0;
    tms_i = 0;
    td_i = 0;
    trst_ni = 0;
    simulation_done = 0;
    //#5
    //$readmemh("sram_initial.hex", i_cv32e40p_xilinx.i_sram.memory);
    // Apply reset for a few cycles
    #10 rst_ni = 1;
    trst_ni = 1;

    // Run simulation for 100 time units and finish
    #10000000 
	simulation_done = 1;
	
  end

  // Dump waveforms for debugging (if needed)
  initial begin
    $fsdbDumpfile("waveform.fsdb");
    $fsdbDumpvars(0, cv32e40p_xilinx_tb);
    $fsdbDumpMDA();
  end

  always @(posedge simulation_done) begin
        if (simulation_done) begin
            $display("==========================================================");
            $display("== Simulation Finished: C code entered infinite loop.   ==");
            $display("== Dumping SRAM1 content to sram1_dump.hex              ==");
            $display("==========================================================");

            // 使用 $writememh 将 SRAM1 的内容写入文件
            $writememh("dcache.hex", i_cv32e40p_xilinx.i_sram_d.mem, 0, 2047);
	    
            
            $display("Dump complete. Finishing simulation.");
            $finish; // 结束仿真
        end
  end

endmodule
